package businesslogic.turn;

public class TurnManager {

    public ShiftBoard getShiftBoard(){
        return ShiftBoard.getInstance();
    }
}
