package businesslogic.user;

public class Service implements Behaviour{ }
