package businesslogic.user;

class Chef implements Behaviour { }