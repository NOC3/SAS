package businesslogic.user;

public class Organizer implements Behaviour { }
