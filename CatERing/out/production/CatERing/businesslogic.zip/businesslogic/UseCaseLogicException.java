package businesslogic;

public class UseCaseLogicException extends Exception {
}
