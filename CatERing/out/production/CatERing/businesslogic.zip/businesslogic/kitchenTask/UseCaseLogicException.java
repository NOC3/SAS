package businesslogic.kitchenTask;

public class UseCaseLogicException extends Exception {
}
