package businesslogic.kitchenTask;

public class SummarySheetException extends Exception{
}
